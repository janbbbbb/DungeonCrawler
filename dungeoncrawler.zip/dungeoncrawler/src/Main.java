import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        DungeonGenerator generator = new DungeonGenerator();
        Tile[][][] dungeons = generator.generateDungeons(3); // Generujemy 3 poziomy lochów
        Player player = new Player(1, 1);
        dungeons[0][1][1].setType(Tile.Type.PLAYER); // Ustawienie gracza na pierwszym poziomie
        JFrame frame = new JFrame("Dungeon Crawler");
        GamePanel gamePanel = new GamePanel(dungeons, player);
        frame.add(gamePanel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
