public class Tile {
    private Type type;

    public Tile(Type type) {
        this.type = type;
    }

    public Type getType() {
        return this.type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String toString() {
        switch (this.type) {
            case WALL:
                return "#";
            case PLAYER:
                return "P";
            case MONSTER:
                return "M";
            case STAIRS:
                return "S";
            default:
                return ".";
        }
    }

    public enum Type {
        EMPTY,
        WALL,
        PLAYER,
        MONSTER,
        STAIRS;
    }
}
