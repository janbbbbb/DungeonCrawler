import java.util.Random;

public class DungeonGenerator {
    private static final int WIDTH = 20;
    private static final int HEIGHT = 20;

    public Tile[][] generateDungeon() {
        Tile[][] dungeon = new Tile[WIDTH][HEIGHT];
        Random rand = new Random();

        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                if (rand.nextInt(4) == 0) {
                    dungeon[i][j] = new Tile(Tile.Type.WALL);
                } else {
                    dungeon[i][j] = new Tile(Tile.Type.EMPTY);
                }
            }
        }

        // Dodajemy przejście na następny poziom na środku
        dungeon[WIDTH / 2][HEIGHT / 2] = new Tile(Tile.Type.STAIRS);
        return dungeon;
    }

    public Tile[][][] generateDungeons(int levels) {
        Tile[][][] dungeons = new Tile[levels][][];
        for (int i = 0; i < levels; i++) {
            dungeons[i] = generateDungeon();
        }
        return dungeons;
    }
}
