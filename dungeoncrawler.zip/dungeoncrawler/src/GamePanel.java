import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel {
    private static final int TILE_SIZE = 50;
    private Tile[][][] dungeons;
    private Player player;
    private int currentLevel;

    public GamePanel(Tile[][][] dungeons, Player player) {
        this.dungeons = dungeons;
        this.player = player;
        this.currentLevel = 0;
        this.setPreferredSize(new Dimension(dungeons[0].length * TILE_SIZE, dungeons[0][0].length * TILE_SIZE));

        this.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                int x = player.getX();
                int y = player.getY();
                switch (key) {
                    case KeyEvent.VK_W:
                    case KeyEvent.VK_UP:
                        movePlayer(x, y - 1);
                        break;
                    case KeyEvent.VK_S:
                    case KeyEvent.VK_DOWN:
                        movePlayer(x, y + 1);
                        break;
                    case KeyEvent.VK_A:
                    case KeyEvent.VK_LEFT:
                        movePlayer(x - 1, y);
                        break;
                    case KeyEvent.VK_D:
                    case KeyEvent.VK_RIGHT:
                        movePlayer(x + 1, y);
                        break;
                }
            }
        });

        this.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX() / TILE_SIZE;
                int y = e.getY() / TILE_SIZE;
                handleMouseClick(x, y);
            }
        });

        this.setFocusable(true);
    }

    private void handleMouseClick(int x, int y) {
        if (isValidMove(x, y)) {
            LinkedList<Point> path = findShortestPath(player.getX(), player.getY(), x, y);
            if (path != null) {
                Timer timer = new Timer(50, null);
                timer.addActionListener(e -> {
                    if (!path.isEmpty()) {
                        Point p = path.removeFirst();
                        movePlayer(p.x, p.y);
                    } else {
                        ((Timer)e.getSource()).stop();
                    }
                });
                timer.start();
            }
        }
    }

    private LinkedList<Point> findShortestPath(int startX, int startY, int goalX, int goalY) {
        boolean[][] visited = new boolean[dungeons[currentLevel].length][dungeons[currentLevel][0].length];
        Point[][] parent = new Point[dungeons[currentLevel].length][dungeons[currentLevel][0].length];
        Queue<Point> queue = new LinkedList<>();
        queue.add(new Point(startX, startY));
        visited[startX][startY] = true;

        int[] dx = {1, -1, 0, 0};
        int[] dy = {0, 0, 1, -1};

        while (!queue.isEmpty()) {
            Point p = queue.poll();
            if (p.x == goalX && p.y == goalY) {
                LinkedList<Point> path = new LinkedList<>();
                for (Point at = p; at != null; at = parent[at.x][at.y]) {
                    path.addFirst(at);
                }
                return path;
            }

            for (int i = 0; i < 4; i++) {
                int newX = p.x + dx[i];
                int newY = p.y + dy[i];
                if (isValidMove(newX, newY) && !visited[newX][newY]) {
                    queue.add(new Point(newX, newY));
                    visited[newX][newY] = true;
                    parent[newX][newY] = p;
                }
            }
        }

        return null; // brak ścieżki
    }

    private void movePlayer(int newX, int newY) {
        if (isValidMove(newX, newY)) {
            Tile nextTile = dungeons[currentLevel][newX][newY];

            if (nextTile.getType() == Tile.Type.STAIRS) {
                // Sprawdzenie przejścia na następny poziom
                if (currentLevel < dungeons.length - 1) {
                    currentLevel++;
                    player.moveTo(1, 1); // reset pozycji gracza
                    dungeons[currentLevel][1][1].setType(Tile.Type.PLAYER);
                    repaint();
                } else {
                    // Ostatni poziom - wygrana
                    JOptionPane.showMessageDialog(this, "Gratulacje, wygrałeś!", "Wygrana", JOptionPane.INFORMATION_MESSAGE);
                }
                return; // opuszczamy metodę, aby nie kontynuować zmiany typu kafelka
            }

            dungeons[currentLevel][player.getX()][player.getY()].setType(Tile.Type.EMPTY);
            player.moveTo(newX, newY);
            nextTile.setType(Tile.Type.PLAYER);
            repaint();
        }
    }

    private boolean isValidMove(int x, int y) {
        return x >= 0 && x < dungeons[currentLevel].length && y >= 0 && y < dungeons[currentLevel][0].length &&
                (dungeons[currentLevel][x][y].getType() == Tile.Type.EMPTY || dungeons[currentLevel][x][y].getType() == Tile.Type.STAIRS);
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int i = 0; i < dungeons[currentLevel].length; ++i) {
            for (int j = 0; j < dungeons[currentLevel][i].length; ++j) {
                drawTile(g, dungeons[currentLevel][i][j], i, j);
            }
        }
    }

    private void drawTile(Graphics g, Tile tile, int x, int y) {
        switch (tile.getType()) {
            case EMPTY:
                g.setColor(Color.WHITE);
                break;
            case WALL:
                g.setColor(Color.BLACK);
                break;
            case PLAYER:
                g.setColor(Color.BLUE);
                break;
            case MONSTER:
                g.setColor(Color.RED);
                break;
            case STAIRS:
                g.setColor(Color.GREEN);
        }

        g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        g.setColor(Color.GRAY);
        g.drawRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    }
}

